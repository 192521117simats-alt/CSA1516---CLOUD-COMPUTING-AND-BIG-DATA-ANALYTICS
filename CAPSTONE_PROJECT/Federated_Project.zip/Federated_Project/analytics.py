import json
import time
import numpy as np

from data_utils import create_client_data


# ============================================================
# BIG DATA ANALYTICS MODULE
# ============================================================

def analyze_client(client_id):
    """
    Analyze the local dataset of one federated client.
    Raw data is loaded locally for analytics only.
    """

    start_time = time.time()

    X, y, X_test, y_test = create_client_data(client_id)

    analysis_time = time.time() - start_time

    total_samples = len(X)
    test_samples = len(X_test)
    features = X.shape[1]

    class_0 = int(np.sum(y == 0))
    class_1 = int(np.sum(y == 1))

    return {
        "client_id": client_id,
        "training_samples": total_samples,
        "test_samples": test_samples,
        "features": features,
        "class_0": class_0,
        "class_1": class_1,
        "processing_time": round(analysis_time, 4)
    }


def analyze_all_clients():
    """
    Perform analytics for all federated clients.
    """

    print("\n" + "=" * 60)
    print("📊 BIG DATA ANALYTICS MODULE")
    print("=" * 60)

    clients = []

    # --------------------------------------------------------
    # Analyze Client 1
    # --------------------------------------------------------

    print("\n🔍 Analyzing Client 1...")

    client1 = analyze_client(1)

    print(
        f"Client 1 | "
        f"Training Samples: {client1['training_samples']} | "
        f"Features: {client1['features']}"
    )

    clients.append(client1)

    # --------------------------------------------------------
    # Analyze Client 2
    # --------------------------------------------------------

    print("\n🔍 Analyzing Client 2...")

    client2 = analyze_client(2)

    print(
        f"Client 2 | "
        f"Training Samples: {client2['training_samples']} | "
        f"Features: {client2['features']}"
    )

    clients.append(client2)

    # --------------------------------------------------------
    # Global statistics
    # --------------------------------------------------------

    total_training_samples = sum(
        client["training_samples"]
        for client in clients
    )

    total_test_samples = sum(
        client["test_samples"]
        for client in clients
    )

    total_class_0 = sum(
        client["class_0"]
        for client in clients
    )

    total_class_1 = sum(
        client["class_1"]
        for client in clients
    )

    total_features = clients[0]["features"]

    # --------------------------------------------------------
    # Analytics result
    # --------------------------------------------------------

    analytics = {
        "total_clients": len(clients),
        "total_training_samples": total_training_samples,
        "total_test_samples": total_test_samples,
        "total_features": total_features,
        "class_distribution": {
            "class_0": total_class_0,
            "class_1": total_class_1
        },
        "clients": clients
    }

    # --------------------------------------------------------
    # Save analytics
    # --------------------------------------------------------

    with open("analytics_results.json", "w") as file:
        json.dump(analytics, file, indent=4)

    # --------------------------------------------------------
    # Display results
    # --------------------------------------------------------

    print("\n" + "=" * 60)
    print("📈 GLOBAL BIG DATA ANALYTICS")
    print("=" * 60)

    print(f"👥 Total Clients          : {len(clients)}")
    print(f"📚 Training Samples       : {total_training_samples}")
    print(f"🧪 Test Samples           : {total_test_samples}")
    print(f"🔢 Features               : {total_features}")
    print(f"🟢 Class 0 Samples        : {total_class_0}")
    print(f"🔴 Class 1 Samples        : {total_class_1}")

    print("\n🔐 Privacy Status:")
    print("Raw client data remains local.")
    print("Only model parameters are communicated.")

    print("\n💾 Analytics saved to:")
    print("analytics_results.json")

    print("\n" + "=" * 60)
    print("✅ BIG DATA ANALYTICS COMPLETED")
    print("=" * 60)


# ============================================================
# MAIN PROGRAM
# ============================================================

if __name__ == "__main__":
    analyze_all_clients()
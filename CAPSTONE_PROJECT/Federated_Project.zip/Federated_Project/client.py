import os
import sys

import torch
import torch.nn as nn
import torch.optim as optim
import flwr as fl

from model import FederatedModel
from data_utils import create_client_data


# ============================================================
# CLIENT CONFIGURATION
# ============================================================

if len(sys.argv) < 2:

    print(
        "❌ Client ID required."
    )

    print(
        "Usage: python client.py 1"
    )

    sys.exit(1)


CLIENT_ID = int(
    sys.argv[1]
)


SERVER_HOST = os.getenv(
    "FL_SERVER_HOST",
    "20.235.35.154"
)

SERVER_PORT = int(
    os.getenv(
        "FL_SERVER_PORT",
        "8080"
    )
)


SERVER_ADDRESS = (
    f"{SERVER_HOST}:{SERVER_PORT}"
)


print("=" * 60)

print(
    f"👤 FEDERATED CLIENT {CLIENT_ID}"
)

print("=" * 60)

print(
    f"🌐 Server: {SERVER_ADDRESS}"
)


# ============================================================
# LOAD CLIENT DATA
# ============================================================

X_train, X_test, y_train, y_test = (
    create_client_data(CLIENT_ID)
)


print(
    f"📚 Training samples: {len(X_train)}"
)

print(
    f"🧪 Test samples: {len(X_test)}"
)

print(
    f"🔢 Features: {X_train.shape[1]}"
)


# ============================================================
# FLOWER CLIENT
# ============================================================

class FlowerClient(
    fl.client.NumPyClient
):

    def __init__(self):

        self.model = FederatedModel()

        self.X_train = torch.tensor(
            X_train,
            dtype=torch.float32
        )

        self.y_train = torch.tensor(
            y_train,
            dtype=torch.float32
        ).reshape(-1, 1)

        self.X_test = torch.tensor(
            X_test,
            dtype=torch.float32
        )

        self.y_test = torch.tensor(
            y_test,
            dtype=torch.float32
        ).reshape(-1, 1)


    # ========================================================
    # GET PARAMETERS
    # ========================================================

    def get_parameters(
        self,
        config
    ):

        return [
            value.detach()
            .cpu()
            .numpy()
            for value in self.model.state_dict().values()
        ]


    # ========================================================
    # SET PARAMETERS
    # ========================================================

    def set_parameters(
        self,
        parameters
    ):

        state_dict = self.model.state_dict()

        new_state_dict = {}

        for key, value in zip(
            state_dict.keys(),
            parameters
        ):

            new_state_dict[key] = torch.tensor(
                value
            )

        self.model.load_state_dict(
            new_state_dict
        )


    # ========================================================
    # LOCAL TRAINING
    # ========================================================

    def fit(
        self,
        parameters,
        config
    ):

        self.set_parameters(
            parameters
        )

        self.model.train()

        optimizer = optim.Adam(
            self.model.parameters(),
            lr=0.001
        )

        criterion = nn.BCEWithLogitsLoss()

        for epoch in range(5):

            optimizer.zero_grad()

            output = self.model(
                self.X_train
            )

            loss = criterion(
                output,
                self.y_train
            )

            loss.backward()

            optimizer.step()


        print(
            f"✅ Client {CLIENT_ID} "
            f"local training completed"
        )

        return (
            self.get_parameters(config),
            len(self.X_train),
            {}
        )


    # ========================================================
    # LOCAL EVALUATION
    # ========================================================

    def evaluate(
        self,
        parameters,
        config
    ):

        self.set_parameters(
            parameters
        )

        self.model.eval()

        with torch.no_grad():

            output = self.model(
                self.X_test
            )

            probabilities = torch.sigmoid(
                output
            )

            predictions = (
                probabilities >= 0.5
            ).float()

            correct = (
                predictions ==
                self.y_test
            ).sum().item()

            accuracy = (
                correct /
                len(self.y_test)
            )

            loss = nn.BCEWithLogitsLoss()(
                output,
                self.y_test
            ).item()


        print(
            f"📊 Client {CLIENT_ID} "
            f"| Accuracy: "
            f"{accuracy * 100:.2f}%"
        )

        return (
            loss,
            len(self.X_test),
            {
                "accuracy": accuracy
            }
        )


# ============================================================
# START CLIENT
# ============================================================

print(
    "🚀 Connecting to federated server..."
)

fl.client.start_client(

    server_address=SERVER_ADDRESS,

    client=FlowerClient().to_client()

)
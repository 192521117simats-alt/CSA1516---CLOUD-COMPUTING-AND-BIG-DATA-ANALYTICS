import json
import matplotlib.pyplot as plt


# Load results
with open("results.json", "r") as f:
    results = json.load(f)


rounds = results["rounds"]
accuracy = results["accuracy"]


# Convert accuracy to percentage
accuracy_percent = [
    value * 100 for value in accuracy
]


# Create graph
plt.figure(figsize=(8, 5))

plt.plot(
    rounds,
    accuracy_percent,
    marker="o",
    linewidth=2
)

plt.title("Federated Learning Accuracy")
plt.xlabel("Federated Round")
plt.ylabel("Accuracy (%)")

plt.xticks(rounds)

plt.grid(True)

# Display accuracy values
for x, y in zip(rounds, accuracy_percent):
    plt.text(
        x,
        y,
        f"{y:.2f}%",
        ha="center",
        va="bottom"
    )


plt.tight_layout()

# Save graph
plt.savefig(
    "federated_accuracy.png",
    dpi=300
)

plt.show()


print("✅ Graph saved as federated_accuracy.png")
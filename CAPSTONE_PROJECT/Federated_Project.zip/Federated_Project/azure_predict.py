import os
import json
import numpy as np
import torch

from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

from model import FederatedModel
from data_utils import create_client_data


# ============================================================
# AZURE GLOBAL MODEL PREDICTION
# ============================================================

print("=" * 60)
print("☁️ AZURE GLOBAL FEDERATED MODEL PREDICTION")
print("=" * 60)


# ------------------------------------------------------------
# 1. LOAD ENVIRONMENT VARIABLES
# ------------------------------------------------------------

load_dotenv()

AZURE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME", "federated-results")

BLOB_NAME = "models/global_model.pth"
LOCAL_MODEL = "azure_global_model.pth"


if not AZURE_CONNECTION_STRING:
    print("❌ Azure connection string not found.")
    print("Make sure your .env file contains:")
    print("AZURE_STORAGE_CONNECTION_STRING=...")
    raise SystemExit(1)


# ------------------------------------------------------------
# 2. CONNECT TO AZURE BLOB STORAGE
# ------------------------------------------------------------

print("\n☁️ Connecting to Azure Blob Storage...")

try:
    blob_service_client = BlobServiceClient.from_connection_string(
        AZURE_CONNECTION_STRING
    )

    container_client = blob_service_client.get_container_client(
        CONTAINER_NAME
    )

    print("✅ Azure connection successful")
    print(f"📦 Container: {CONTAINER_NAME}")

except Exception as e:
    print("❌ Azure connection failed")
    print("Error:", e)
    raise SystemExit(1)


# ------------------------------------------------------------
# 3. DOWNLOAD GLOBAL MODEL
# ------------------------------------------------------------

print("\n📥 Downloading global model from Azure...")
print(f"☁️ Blob: {BLOB_NAME}")

try:
    blob_client = container_client.get_blob_client(BLOB_NAME)

    with open(LOCAL_MODEL, "wb") as file:
        download_stream = blob_client.download_blob()
        file.write(download_stream.readall())

    file_size = os.path.getsize(LOCAL_MODEL)

    print("✅ Global model downloaded successfully")
    print(f"📁 Local file: {LOCAL_MODEL}")
    print(f"📊 File size: {file_size:,} bytes")

except Exception as e:
    print("❌ Model download failed")
    print("Error:", e)
    raise SystemExit(1)


# ------------------------------------------------------------
# 4. CREATE TEST DATA
# ------------------------------------------------------------

print("\n🧪 Loading federated test data...")

try:

    X1, y1, Xtest1, ytest1 = create_client_data(1)
    X2, y2, Xtest2, ytest2 = create_client_data(2)

    X_test = np.concatenate([Xtest1, Xtest2], axis=0)
    y_test = np.concatenate([ytest1, ytest2], axis=0)

    print(f"🧪 Test samples: {len(X_test)}")
    print(f"🔢 Features: {X_test.shape[1]}")

except Exception as e:
    print("❌ Test data loading failed")
    print("Error:", e)
    raise SystemExit(1)


# ------------------------------------------------------------
# 5. CREATE MODEL
# ------------------------------------------------------------

print("\n🧠 Loading PyTorch global model...")

try:

    model = FederatedModel()

    checkpoint = torch.load(
        LOCAL_MODEL,
        map_location=torch.device("cpu")
    )

    # Handle either a complete state_dict or a wrapped checkpoint
    if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
        state_dict = checkpoint["state_dict"]
    else:
        state_dict = checkpoint

    model.load_state_dict(state_dict)

    model.eval()

    print("✅ Global federated model loaded")
    print("✅ Model is ready for prediction")

except Exception as e:
    print("❌ Model loading failed")
    print("Error:", e)
    raise SystemExit(1)


# ------------------------------------------------------------
# 6. RUN PREDICTIONS
# ------------------------------------------------------------

print("\n🔮 Running predictions...")

try:

    X_tensor = torch.tensor(
        X_test,
        dtype=torch.float32
    )

    y_tensor = torch.tensor(
        y_test,
        dtype=torch.float32
    ).reshape(-1, 1)

    with torch.no_grad():

        outputs = model(X_tensor)

        probabilities = torch.sigmoid(outputs)

        predictions = (
            probabilities >= 0.5
        ).float()

    correct = (
        predictions == y_tensor
    ).sum().item()

    total = len(y_test)

    accuracy = correct / total

except Exception as e:
    print("❌ Prediction failed")
    print("Error:", e)
    raise SystemExit(1)


# ------------------------------------------------------------
# 7. DISPLAY RESULTS
# ------------------------------------------------------------

print("\n" + "=" * 60)
print("📊 AZURE GLOBAL MODEL RESULTS")
print("=" * 60)

print(f"🧪 Test Samples          : {total}")
print(f"✅ Correct Predictions   : {correct}")
print(f"❌ Incorrect Predictions : {total - correct}")
print(f"🎯 Model Accuracy        : {accuracy * 100:.2f}%")


# ------------------------------------------------------------
# 8. SAMPLE PREDICTIONS
# ------------------------------------------------------------

print("\n" + "=" * 60)
print("🔍 SAMPLE PREDICTIONS")
print("=" * 60)

sample_count = min(10, total)

for i in range(sample_count):

    actual = int(y_test[i])
    predicted = int(predictions[i].item())
    confidence = float(probabilities[i].item())

    status = "✅" if actual == predicted else "❌"

    print(
        f"{status} Sample {i + 1:02d} | "
        f"Actual: {actual} | "
        f"Predicted: {predicted} | "
        f"Confidence: {confidence:.2f}"
    )


# ------------------------------------------------------------
# 9. SAVE AZURE PREDICTION RESULTS
# ------------------------------------------------------------

prediction_results = {

    "source": "Azure Blob Storage",

    "model_blob": BLOB_NAME,

    "local_model": LOCAL_MODEL,

    "test_samples": int(total),

    "correct_predictions": int(correct),

    "incorrect_predictions": int(total - correct),

    "accuracy": float(accuracy),

    "accuracy_percent": float(accuracy * 100)

}


with open(
    "azure_prediction_results.json",
    "w"
) as f:

    json.dump(
        prediction_results,
        f,
        indent=4
    )


print("\n💾 Results saved to:")
print("   azure_prediction_results.json")


# ------------------------------------------------------------
# 10. FINAL STATUS
# ------------------------------------------------------------

print("\n" + "=" * 60)
print("🎉 AZURE PREDICTION COMPLETED")
print("=" * 60)

print("☁️ Azure Blob Storage → Global Model")
print("🧠 Global Model → Local Prediction")
print("📊 Test Dataset → Accuracy Evaluation")
print("🔐 Federated raw client data remains local")

print("=" * 60)
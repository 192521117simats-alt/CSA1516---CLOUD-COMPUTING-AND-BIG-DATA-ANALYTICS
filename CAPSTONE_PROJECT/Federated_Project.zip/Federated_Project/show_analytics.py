import json

with open("analytics_results.json", "r") as f:
    d = json.load(f)

print("=" * 50)
print("        BIG DATA ANALYTICS")
print("=" * 50)

print("Total Clients:", d["total_clients"])
print("Training Samples:", d["total_training_samples"])
print("Test Samples:", d["total_test_samples"])
print("Features:", d["total_features"])

print("Class 0:", d["class_distribution"]["class_0"])
print("Class 1:", d["class_distribution"]["class_1"])

print()
print("---------- CLIENT DETAILS ----------")

for c in d["clients"]:
    print(
        f"Client {c['client_id']}: "
        f"Train={c['training_samples']}, "
        f"Test={c['test_samples']}, "
        f"Features={c['features']}"
    )
import json

with open("results.json", "r") as f:
    d = json.load(f)

print("=" * 50)
print("        FEDERATED LEARNING RESULTS")
print("=" * 50)

for r, a in zip(d["rounds"], d["accuracy"]):
    print(f"Round {r}: Accuracy = {a * 100:.2f}%")

print()
print(f"Initial Accuracy: {d['accuracy'][0] * 100:.2f}%")
print(f"Final Accuracy: {d['accuracy'][-1] * 100:.2f}%")

improvement = (
    d["accuracy"][-1] - d["accuracy"][0]
) * 100

print(f"Improvement: {improvement:+.2f}%")
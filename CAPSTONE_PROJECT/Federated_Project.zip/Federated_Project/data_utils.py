import pandas as pd
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def create_client_data(client_id):
    """
    Create a separate local dataset for each federated client.
    Raw data stays inside the client.
    """

    data = load_breast_cancer()

    X = data.data
    y = data.target

    # Split the complete dataset into two local clients
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    # Create different local partitions
    if client_id == 1:
        X_local = X_train[:len(X_train) // 2]
        y_local = y_train[:len(y_train) // 2]

    else:
        X_local = X_train[len(X_train) // 2:]
        y_local = y_train[len(y_train) // 2:]

    # Local preprocessing
    scaler = StandardScaler()

    X_local = scaler.fit_transform(X_local)

    X_test = scaler.transform(X_test)

    return (
        X_local.astype(np.float32),
        y_local.astype(np.float32),
        X_test.astype(np.float32),
        y_test.astype(np.float32)
    )
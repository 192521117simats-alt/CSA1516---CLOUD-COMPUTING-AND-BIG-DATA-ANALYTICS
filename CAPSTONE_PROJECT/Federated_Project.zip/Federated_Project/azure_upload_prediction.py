import os
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

# ============================================================
# AZURE PREDICTION RESULTS UPLOAD
# ============================================================

print("=" * 60)
print("☁️ AZURE PREDICTION RESULTS UPLOAD")
print("=" * 60)

# Load environment variables
load_dotenv()

connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
container_name = os.getenv("AZURE_STORAGE_CONTAINER", "federated-results")

if not connection_string:
    print("❌ Azure Storage connection string not found.")
    print("Check your .env file.")
    raise SystemExit(1)

# ------------------------------------------------------------
# Connect to Azure Blob Storage
# ------------------------------------------------------------

try:
    blob_service_client = BlobServiceClient.from_connection_string(
        connection_string
    )

    container_client = blob_service_client.get_container_client(
        container_name
    )

    print("✅ Azure connection successful")
    print(f"📦 Container: {container_name}")

except Exception as e:
    print("❌ Azure connection failed")
    print(f"Error: {e}")
    raise SystemExit(1)

# ------------------------------------------------------------
# Prediction result file
# ------------------------------------------------------------

local_file = "azure_prediction_results.json"
blob_name = "predictions/azure_prediction_results.json"

if not os.path.exists(local_file):
    print()
    print(f"❌ File not found: {local_file}")
    print()
    print("Run this first:")
    print("python azure_predict.py")
    raise SystemExit(1)

file_size = os.path.getsize(local_file)

print()
print("📤 Uploading prediction results...")
print(f"📄 Local file : {local_file}")
print(f"☁️ Azure Blob : {blob_name}")
print(f"📊 File size  : {file_size:,} bytes")

# ------------------------------------------------------------
# Upload
# ------------------------------------------------------------

try:
    with open(local_file, "rb") as data:
        container_client.upload_blob(
            name=blob_name,
            data=data,
            overwrite=True
        )

    print()
    print("✅ Prediction results uploaded successfully!")

except Exception as e:
    print()
    print("❌ Upload failed")
    print(f"Error: {e}")
    raise SystemExit(1)

# ------------------------------------------------------------
# Verify upload
# ------------------------------------------------------------

try:
    blob_client = container_client.get_blob_client(blob_name)
    properties = blob_client.get_blob_properties()

    print()
    print("🔍 Azure upload verification")
    print(f"✅ Blob exists: {blob_name}")
    print(f"📊 Azure size : {properties.size:,} bytes")

except Exception as e:
    print()
    print("⚠️ Upload completed, but verification failed.")
    print(f"Error: {e}")

# ------------------------------------------------------------
# Final message
# ------------------------------------------------------------

print()
print("=" * 60)
print("🎉 PREDICTION RESULTS STORED IN AZURE")
print("=" * 60)

print()
print("☁️ Azure Blob Storage:")
print("federated-results/")
print("├── results/")
print("│   └── results.json")
print("├── analytics/")
print("│   └── analytics_results.json")
print("├── models/")
print("│   └── global_model.pth")
print("└── predictions/")
print("    └── azure_prediction_results.json")

print()
print("🔐 Federated raw client data remains local.")
print("🧠 Global model prediction results are stored in Azure.")
print("=" * 60)
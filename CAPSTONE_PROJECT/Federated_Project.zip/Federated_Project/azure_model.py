import os
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

load_dotenv()

AZURE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = "federated-results"
BLOB_NAME = "models/global_model.pth"
LOCAL_FILE = "azure_global_model.pth"


def download_global_model():
    print("=" * 60)
    print("☁️ AZURE GLOBAL MODEL DOWNLOAD")
    print("=" * 60)

    if not AZURE_CONNECTION_STRING:
        print("❌ Azure connection string not found")
        return False

    try:
        blob_service_client = BlobServiceClient.from_connection_string(
            AZURE_CONNECTION_STRING
        )

        container_client = blob_service_client.get_container_client(
            CONTAINER_NAME
        )

        blob_client = container_client.get_blob_client(BLOB_NAME)

        print(f"☁️ Container : {CONTAINER_NAME}")
        print(f"📦 Blob      : {BLOB_NAME}")
        print()

        with open(LOCAL_FILE, "wb") as file:
            download_stream = blob_client.download_blob()
            file.write(download_stream.readall())

        size = os.path.getsize(LOCAL_FILE)

        print("✅ Global model downloaded successfully")
        print(f"📁 Local file: {LOCAL_FILE}")
        print(f"📊 File size : {size:,} bytes")
        print()
        print("🎉 Azure → Local model transfer successful")

        return True

    except Exception as e:
        print("❌ Azure model download failed")
        print(f"Error: {e}")
        return False


if __name__ == "__main__":
    download_global_model()
    
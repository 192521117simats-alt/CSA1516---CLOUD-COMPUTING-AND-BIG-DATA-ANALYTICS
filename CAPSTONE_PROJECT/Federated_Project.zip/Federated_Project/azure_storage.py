import os
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

AZURE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME", "federated-results")

if not AZURE_CONNECTION_STRING:
    print("❌ Azure connection string not found.")
    print("Check your .env file.")
    exit()

# ============================================================
# AZURE CONNECTION
# ============================================================

print()
print("=" * 60)
print("☁️ AZURE FEDERATED STORAGE")
print("=" * 60)

try:
    blob_service_client = BlobServiceClient.from_connection_string(
        AZURE_CONNECTION_STRING
    )

    container_client = blob_service_client.get_container_client(
        CONTAINER_NAME
    )

    # Test connection
    container_client.get_container_properties()

    print("✅ Azure connection successful!")
    print(f"☁️ Container: {CONTAINER_NAME}")

except Exception as e:
    print("❌ Azure connection failed")
    print(e)
    exit()

# ============================================================
# UPLOAD FUNCTION
# ============================================================

def upload_file(local_file, blob_path):

    if not os.path.exists(local_file):
        print(f"❌ Local file not found: {local_file}")
        return False

    try:
        blob_client = container_client.get_blob_client(blob_path)

        with open(local_file, "rb") as data:
            blob_client.upload_blob(
                data,
                overwrite=True
            )

        file_size = os.path.getsize(local_file)

        print(f"☁️ Uploaded: {local_file}")
        print(f"   Azure Blob: {blob_path}")
        print(f"   Size: {file_size} bytes")

        return True

    except Exception as e:
        print(f"❌ Upload failed: {local_file}")
        print(e)
        return False


# ============================================================
# UPLOAD FEDERATED RESULTS
# ============================================================

print()
print("📤 Uploading federated learning results...")

upload_file(
    "results.json",
    "test/results.json"
)

# ============================================================
# UPLOAD BIG DATA ANALYTICS
# ============================================================

print()
print("📤 Uploading big data analytics...")

upload_file(
    "analytics_results.json",
    "analytics/analytics_results.json"
)

# ============================================================
# UPLOAD GLOBAL MODEL
# ============================================================

print()
print("📤 Uploading global federated model...")

if os.path.exists("global_model.pth"):

    upload_file(
        "global_model.pth",
        "models/global_model.pth"
    )

else:
    print("⚠️ global_model.pth not found")

# ============================================================
# VERIFY AZURE FILES
# ============================================================

print()
print("=" * 60)
print("🔍 AZURE STORAGE VERIFICATION")
print("=" * 60)

try:

    blobs = container_client.list_blobs()

    found = False

    for blob in blobs:
        print(f"☁️ {blob.name}")
        found = True

    if not found:
        print("⚠️ No files found in container.")

except Exception as e:
    print("❌ Could not list Azure files")
    print(e)

# ============================================================
# COMPLETE
# ============================================================

print()
print("=" * 60)
print("✅ AZURE STORAGE UPDATE COMPLETED")
print("=" * 60)
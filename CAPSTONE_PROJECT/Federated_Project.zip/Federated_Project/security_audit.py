import json
import os
import hashlib
from datetime import datetime, timezone


# ============================================================
# SECURITY + AUDIT LOGGING MODULE
# Privacy-Preserving Federated Learning Project
# ============================================================

AUDIT_FILE = "audit_log.json"


# ============================================================
# TIMESTAMP
# ============================================================

def get_timestamp():
    return datetime.now(timezone.utc).isoformat()


# ============================================================
# FILE HASH
# ============================================================

def calculate_file_hash(file_path):

    if not os.path.exists(file_path):
        return None

    sha256 = hashlib.sha256()

    with open(file_path, "rb") as file:

        while True:

            data = file.read(8192)

            if not data:
                break

            sha256.update(data)

    return sha256.hexdigest()


# ============================================================
# LOAD AUDIT LOG
# ============================================================

def load_audit_log():

    if not os.path.exists(AUDIT_FILE):
        return []

    try:

        with open(
            AUDIT_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            data = json.load(file)

            if isinstance(data, list):
                return data

    except Exception:
        pass

    return []


# ============================================================
# SAVE AUDIT LOG
# ============================================================

def save_audit_log(logs):

    with open(
        AUDIT_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            logs,
            file,
            indent=4
        )


# ============================================================
# ADD AUDIT EVENT
# ============================================================

def log_event(
    event_type,
    component,
    status,
    message,
    metadata=None
):

    logs = load_audit_log()

    event = {

        "timestamp": get_timestamp(),

        "event_id": len(logs) + 1,

        "event_type": event_type,

        "component": component,

        "status": status,

        "message": message,

        "metadata": metadata or {}
    }

    logs.append(event)

    save_audit_log(logs)

    return event


# ============================================================
# LOG FEDERATED ROUND
# ============================================================

def log_federated_round(
    round_number,
    accuracy,
    clients
):

    return log_event(

        event_type="FEDERATED_ROUND",

        component="Flower Federated Server",

        status="SUCCESS",

        message=(
            f"Federated round {round_number} "
            f"completed successfully."
        ),

        metadata={

            "round": round_number,

            "accuracy": accuracy,

            "participating_clients": clients,

            "aggregation": "FedAvg",

            "raw_data_transferred": False
        }
    )


# ============================================================
# LOG CLIENT TRAINING
# ============================================================

def log_client_training(
    client_id,
    samples,
    accuracy
):

    return log_event(

        event_type="LOCAL_TRAINING",

        component=f"Client {client_id}",

        status="SUCCESS",

        message=(
            f"Client {client_id} completed "
            f"local model training."
        ),

        metadata={

            "client_id": client_id,

            "training_samples": samples,

            "local_accuracy": accuracy,

            "raw_data_shared": False
        }
    )


# ============================================================
# LOG AZURE UPLOAD
# ============================================================

def log_azure_upload(
    blob_name,
    local_file,
    file_size
):

    file_hash = calculate_file_hash(local_file)

    return log_event(

        event_type="AZURE_UPLOAD",

        component="Azure Blob Storage",

        status="SUCCESS",

        message=(
            f"File uploaded successfully to Azure: "
            f"{blob_name}"
        ),

        metadata={

            "blob_name": blob_name,

            "local_file": local_file,

            "file_size": file_size,

            "sha256": file_hash
        }
    )


# ============================================================
# LOG MODEL DOWNLOAD
# ============================================================

def log_model_download(
    blob_name,
    local_file
):

    file_hash = calculate_file_hash(local_file)

    file_size = (
        os.path.getsize(local_file)
        if os.path.exists(local_file)
        else 0
    )

    return log_event(

        event_type="MODEL_DOWNLOAD",

        component="Azure Blob Storage",

        status="SUCCESS",

        message=(
            "Global federated model "
            "downloaded successfully."
        ),

        metadata={

            "blob_name": blob_name,

            "local_file": local_file,

            "file_size": file_size,

            "sha256": file_hash
        }
    )


# ============================================================
# LOG PREDICTION
# ============================================================

def log_prediction(
    prediction,
    confidence,
    model_source="global_model.pth"
):

    return log_event(

        event_type="PREDICTION",

        component="Global Federated Model",

        status="SUCCESS",

        message=(
            f"Prediction completed: "
            f"class {prediction}"
        ),

        metadata={

            "prediction": prediction,

            "confidence": confidence,

            "model_source": model_source
        }
    )


# ============================================================
# LOG SECURITY EVENT
# ============================================================

def log_security_event(
    event_type,
    status,
    message,
    metadata=None
):

    return log_event(

        event_type=event_type,

        component="Security Layer",

        status=status,

        message=message,

        metadata=metadata
    )


# ============================================================
# SYSTEM SECURITY SUMMARY
# ============================================================

def security_summary():

    logs = load_audit_log()

    total_events = len(logs)

    successful_events = sum(
        1
        for event in logs
        if event.get("status") == "SUCCESS"
    )

    failed_events = sum(
        1
        for event in logs
        if event.get("status") == "FAILED"
    )

    return {

        "total_events": total_events,

        "successful_events": successful_events,

        "failed_events": failed_events,

        "raw_client_data_shared": False,

        "model_parameters_shared": True,

        "audit_logging": True,

        "sha256_integrity": True
    }


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print("=" * 60)
    print("🔐 SECURITY + AUDIT LOGGING MODULE")
    print("=" * 60)

    event = log_event(

        event_type="SYSTEM_START",

        component="Federated Learning System",

        status="SUCCESS",

        message=(
            "Security and audit logging "
            "module initialized."
        ),

        metadata={

            "privacy_protection": True,

            "audit_enabled": True,

            "hash_integrity": True
        }
    )

    print()
    print("✅ Audit event created")
    print()

    print("📋 Event ID       :", event["event_id"])
    print("🕒 Timestamp      :", event["timestamp"])
    print("🔐 Event Type     :", event["event_type"])
    print("🧩 Component      :", event["component"])
    print("✅ Status          :", event["status"])

    print()
    print("📊 SECURITY SUMMARY")
    print("-" * 60)

    summary = security_summary()

    for key, value in summary.items():

        print(
            f"{key.replace('_', ' ').title():30}: {value}"
        )

    print()
    print("💾 Audit log saved to:")
    print(f"   {AUDIT_FILE}")

    print()
    print("=" * 60)
    print("🎉 SECURITY MODULE TEST COMPLETED")
    print("=" * 60)
import streamlit as st
import json
import os
import pandas as pd
import plotly.graph_objects as go

from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient


# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

st.set_page_config(
    page_title="Federated Learning Dashboard",
    page_icon="🔐",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 0.2rem;
    }

    .subtitle {
        font-size: 1.15rem;
        color: #777;
        margin-bottom: 1.5rem;
    }

    .section-title {
        font-size: 1.5rem;
        font-weight: 700;
        margin-top: 1rem;
    }

    .small-note {
        color: #777;
        font-size: 0.9rem;
    }

    .metric-card {
        padding: 10px;
        border-radius: 10px;
    }

    div[data-testid="stMetric"] {
        border: 1px solid rgba(128,128,128,0.18);
        padding: 12px;
        border-radius: 12px;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# AZURE CONFIGURATION
# ============================================================

AZURE_CONNECTION_STRING = os.getenv(
    "AZURE_STORAGE_CONNECTION_STRING"
)

AZURE_CONTAINER = os.getenv(
    "AZURE_CONTAINER_NAME",
    "federated-results"
)

RESULTS_BLOB = "results/results.json"
ANALYTICS_BLOB = "analytics/analytics_results.json"
MODEL_BLOB = "models/global_model.pth"
PREDICTION_BLOB = "predictions/azure_prediction_results.json"


# ============================================================
# AZURE CONNECTION
# ============================================================

azure_client = None
azure_container = None
azure_connected = False

if AZURE_CONNECTION_STRING:

    try:

        azure_client = BlobServiceClient.from_connection_string(
            AZURE_CONNECTION_STRING
        )

        azure_container = azure_client.get_container_client(
            AZURE_CONTAINER
        )

        azure_container.get_container_properties()

        azure_connected = True

    except Exception:

        azure_connected = False

else:

    azure_connected = False


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def load_local_json(filename):

    if not os.path.exists(filename):
        return {}

    try:

        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except Exception:

        return {}


def load_azure_json(blob_name):

    if not azure_connected:
        return {}

    try:

        blob_client = azure_container.get_blob_client(
            blob_name
        )

        data = blob_client.download_blob().readall()

        return json.loads(
            data.decode("utf-8")
        )

    except Exception:

        return {}


def get_first_value(data, keys, default=0):

    if not isinstance(data, dict):
        return default

    for key in keys:

        if key in data:

            value = data[key]

            if value is not None:
                return value

    return default


def find_nested_value(data, keys, default=0):

    if isinstance(data, dict):

        for key in keys:

            if key in data:

                value = data[key]

                if value is not None:
                    return value

        for value in data.values():

            result = find_nested_value(
                value,
                keys,
                None
            )

            if result is not None:
                return result

    elif isinstance(data, list):

        for item in data:

            result = find_nested_value(
                item,
                keys,
                None
            )

            if result is not None:
                return result

    return default


def safe_int(value):

    try:
        return int(float(value))
    except Exception:
        return 0


def safe_float(value):

    try:
        return float(value)
    except Exception:
        return 0.0


# ============================================================
# LOAD FEDERATED RESULTS
# ============================================================

azure_results = {}

if azure_connected:

    azure_results = load_azure_json(
        RESULTS_BLOB
    )

local_results = load_local_json(
    "results.json"
)

if azure_results:

    results_data = azure_results
    results_source = "Azure Blob Storage"

else:

    results_data = local_results
    results_source = "Local results.json"


# ============================================================
# LOAD ANALYTICS
# ============================================================

azure_analytics = {}

if azure_connected:

    azure_analytics = load_azure_json(
        ANALYTICS_BLOB
    )

local_analytics = load_local_json(
    "analytics_results.json"
)

if azure_analytics:

    analytics_data = azure_analytics
    analytics_source = "Azure Blob Storage"

else:

    analytics_data = local_analytics
    analytics_source = "Local analytics_results.json"


# ============================================================
# LOAD PREDICTION RESULTS
# ============================================================

azure_prediction_data = {}

if azure_connected:

    azure_prediction_data = load_azure_json(
        PREDICTION_BLOB
    )

local_prediction_data = load_local_json(
    "azure_prediction_results.json"
)

if azure_prediction_data:

    prediction_data = azure_prediction_data

elif local_prediction_data:

    prediction_data = local_prediction_data

else:

    prediction_data = {}


# ============================================================
# EXTRACT FEDERATED RESULTS
# ============================================================

rounds = []
accuracy_percent = []

if isinstance(results_data, dict):

    rounds = get_first_value(
        results_data,
        [
            "rounds",
            "Rounds",
            "federated_rounds"
        ],
        []
    )

    accuracy_values = get_first_value(
        results_data,
        [
            "accuracy",
            "accuracies",
            "accuracy_history",
            "Accuracy"
        ],
        []
    )

    if isinstance(accuracy_values, list):

        for value in accuracy_values:

            try:

                value = float(value)

                if value <= 1:
                    value *= 100

                accuracy_percent.append(
                    value
                )

            except Exception:

                pass


# ============================================================
# ROUND-WISE FALLBACK
# ============================================================

if not accuracy_percent:

    possible_round_results = find_nested_value(
        results_data,
        [
            "round_results",
            "rounds_results",
            "history"
        ],
        []
    )

    if isinstance(
        possible_round_results,
        list
    ):

        for index, item in enumerate(
            possible_round_results
        ):

            if isinstance(item, dict):

                round_number = get_first_value(
                    item,
                    [
                        "round",
                        "Round"
                    ],
                    index + 1
                )

                accuracy = get_first_value(
                    item,
                    [
                        "accuracy",
                        "Accuracy",
                        "global_accuracy"
                    ],
                    None
                )

                if accuracy is not None:

                    try:

                        accuracy = float(
                            accuracy
                        )

                        if accuracy <= 1:
                            accuracy *= 100

                        rounds.append(
                            round_number
                        )

                        accuracy_percent.append(
                            accuracy
                        )

                    except Exception:

                        pass


# ============================================================
# ROUND NUMBER SAFETY
# ============================================================

if accuracy_percent:

    if not isinstance(rounds, list):
        rounds = []

    if len(rounds) != len(
        accuracy_percent
    ):

        rounds = list(
            range(
                1,
                len(accuracy_percent) + 1
            )
        )


# ============================================================
# BIG DATA ANALYTICS
# ============================================================

total_clients = find_nested_value(
    analytics_data,
    [
        "total_clients",
        "Total Clients",
        "clients_count",
        "num_clients"
    ],
    0
)

training_samples = find_nested_value(
    analytics_data,
    [
        "total_training_samples",
        "training_samples",
        "Training Samples",
        "train_samples"
    ],
    0
)

test_samples = find_nested_value(
    analytics_data,
    [
        "total_test_samples",
        "test_samples",
        "Test Samples"
    ],
    0
)

features = find_nested_value(
    analytics_data,
    [
        "total_features",
        "features",
        "Features",
        "num_features",
        "feature_count"
    ],
    0
)

class_0 = find_nested_value(
    analytics_data,
    [
        "class_0",
        "Class 0",
        "class_0_samples",
        "class0",
        "Class_0"
    ],
    0
)

class_1 = find_nested_value(
    analytics_data,
    [
        "class_1",
        "Class 1",
        "class_1_samples",
        "class1",
        "Class_1"
    ],
    0
)


total_clients = safe_int(total_clients)
training_samples = safe_int(training_samples)
test_samples = safe_int(test_samples)
features = safe_int(features)
class_0 = safe_int(class_0)
class_1 = safe_int(class_1)


# ============================================================
# CLIENT DATA
# ============================================================

clients = find_nested_value(
    analytics_data,
    [
        "clients",
        "client_analytics",
        "client_data",
        "client_results"
    ],
    []
)


if isinstance(clients, list) and clients:

    if total_clients == 0:

        total_clients = len(clients)

    calculated_training = 0
    calculated_test = 0
    calculated_features = 0

    for client in clients:

        if not isinstance(client, dict):
            continue

        calculated_training += safe_int(
            get_first_value(
                client,
                [
                    "training_samples",
                    "Training Samples",
                    "train_samples"
                ],
                0
            )
        )

        calculated_test += safe_int(
            get_first_value(
                client,
                [
                    "test_samples",
                    "Test Samples"
                ],
                0
            )
        )

        client_features = safe_int(
            get_first_value(
                client,
                [
                    "features",
                    "Features",
                    "num_features"
                ],
                0
            )
        )

        calculated_features = max(
            calculated_features,
            client_features
        )

    if training_samples == 0:
        training_samples = calculated_training

    if test_samples == 0:
        test_samples = calculated_test

    if features == 0:
        features = calculated_features


# ============================================================
# HEADER
# ============================================================

st.markdown(
    '<div class="main-title">'
    '🔐 Federated Learning Dashboard'
    '</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Privacy-Preserving Federated Learning with '
    'Cloud-Based Model Aggregation'
    '</div>',
    unsafe_allow_html=True
)


# ============================================================
# AZURE STATUS
# ============================================================

if azure_connected:

    st.success(
        "☁️ Azure Blob Storage: Connected / Results Loaded"
    )

else:

    st.warning(
        "⚠️ Azure Blob Storage unavailable. "
        "Using local project files."
    )


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.header("🔐 System Information")

    st.write(
        "**Technology Stack**"
    )

    st.write(
        "🐍 Python"
    )

    st.write(
        "🔥 PyTorch"
    )

    st.write(
        "🌸 Flower"
    )

    st.write(
        "☁️ Microsoft Azure"
    )

    st.write(
        "📊 Streamlit"
    )

    st.divider()

    st.write(
        "**Azure Container**"
    )

    st.code(
        AZURE_CONTAINER
    )

    st.write(
        "**Model Blob**"
    )

    st.code(
        MODEL_BLOB
    )

    st.write(
        "**Prediction Blob**"
    )

    st.code(
        PREDICTION_BLOB
    )


# ============================================================
# FEDERATED SUMMARY
# ============================================================

st.header(
    "📊 Federated Learning Summary"
)

col1, col2, col3, col4 = st.columns(4)

initial_accuracy = (
    accuracy_percent[0]
    if accuracy_percent
    else 0
)

final_accuracy = (
    accuracy_percent[-1]
    if accuracy_percent
    else 0
)

improvement = (
    final_accuracy -
    initial_accuracy
)

with col1:

    st.metric(
        "Federated Rounds",
        len(rounds)
    )

with col2:

    st.metric(
        "Final Accuracy",
        f"{final_accuracy:.2f}%"
    )

with col3:

    st.metric(
        "Initial Accuracy",
        f"{initial_accuracy:.2f}%"
    )

with col4:

    st.metric(
        "Improvement",
        f"{improvement:+.2f}%"
    )


st.caption(
    f"Federated results source: {results_source}"
)


# ============================================================
# FEDERATED ACCURACY GRAPH
# ============================================================

st.header(
    "📈 Federated Learning Accuracy"
)

if rounds and accuracy_percent:

    fig_accuracy = go.Figure()

    fig_accuracy.add_trace(
        go.Scatter(
            x=rounds,
            y=accuracy_percent,
            mode="lines+markers",
            name="Federated Accuracy",
            line=dict(
                width=4
            ),
            marker=dict(
                size=10
            ),
            text=[
                f"{x:.2f}%"
                for x in accuracy_percent
            ],
            textposition="top center"
        )
    )

    fig_accuracy.update_layout(
        title="Accuracy Across Federated Communication Rounds",
        xaxis_title="Federated Round",
        yaxis_title="Accuracy (%)",
        yaxis=dict(
            range=[
                max(
                    0,
                    min(accuracy_percent) - 5
                ),
                100
            ]
        ),
        height=450,
        hovermode="x unified"
    )

    st.plotly_chart(
        fig_accuracy,
        width="stretch"
    )

else:

    st.info(
        "No round-wise accuracy data available."
    )


# ============================================================
# ROUND-WISE RESULTS
# ============================================================

st.header(
    "📊 Round-wise Results"
)

if rounds and accuracy_percent:

    round_data = pd.DataFrame(
        {
            "Round": rounds,
            "Accuracy (%)": [
                round(
                    value,
                    2
                )
                for value in accuracy_percent
            ]
        }
    )

    st.dataframe(
        round_data,
        width="stretch",
        hide_index=True
    )

else:

    st.info(
        "Round-wise results are not available."
    )


# ============================================================
# BIG DATA ANALYTICS
# ============================================================

st.header(
    "📊 Big Data Analytics"
)

col1, col2, col3, col4 = st.columns(4)

with col1:

    st.metric(
        "👥 Total Clients",
        total_clients
    )

with col2:

    st.metric(
        "📚 Training Samples",
        training_samples
    )

with col3:

    st.metric(
        "🧪 Test Samples",
        test_samples
    )

with col4:

    st.metric(
        "🔢 Features",
        features
    )

st.caption(
    f"Analytics source: {analytics_source}"
)


# ============================================================
# CLIENT-WISE ANALYTICS
# ============================================================

st.subheader(
    "👥 Client-wise Dataset Analytics"
)

if isinstance(clients, list) and clients:

    client_rows = []

    for index, client in enumerate(
        clients
    ):

        if not isinstance(
            client,
            dict
        ):
            continue

        client_name = get_first_value(
            client,
            [
                "client",
                "Client",
                "client_id",
                "Client ID"
            ],
            f"Client {index + 1}"
        )

        client_training = safe_int(
            get_first_value(
                client,
                [
                    "training_samples",
                    "Training Samples",
                    "train_samples"
                ],
                0
            )
        )

        client_test = safe_int(
            get_first_value(
                client,
                [
                    "test_samples",
                    "Test Samples"
                ],
                0
            )
        )

        client_feature_count = safe_int(
            get_first_value(
                client,
                [
                    "features",
                    "Features",
                    "num_features"
                ],
                features
            )
        )

        client_rows.append(
            {
                "Client": client_name,
                "Training Samples": client_training,
                "Test Samples": client_test,
                "Features": client_feature_count
            }
        )

    if client_rows:

        client_df = pd.DataFrame(
            client_rows
        )

        st.dataframe(
            client_df,
            width="stretch",
            hide_index=True
        )

        fig_clients = go.Figure()

        fig_clients.add_trace(
            go.Bar(
                x=client_df["Client"],
                y=client_df["Training Samples"],
                name="Training Samples"
            )
        )

        fig_clients.add_trace(
            go.Bar(
                x=client_df["Client"],
                y=client_df["Test Samples"],
                name="Test Samples"
            )
        )

        fig_clients.update_layout(
            title="Client-wise Dataset Distribution",
            barmode="group",
            xaxis_title="Client",
            yaxis_title="Samples",
            height=420
        )

        st.plotly_chart(
            fig_clients,
            width="stretch"
        )

else:

    st.info(
        "Client-wise analytics data is not available."
    )


# ============================================================
# GLOBAL CLASS DISTRIBUTION
# ============================================================

st.subheader(
    "📊 Global Class Distribution"
)

class_df = pd.DataFrame(
    {
        "Class": [
            "Class 0",
            "Class 1"
        ],
        "Samples": [
            class_0,
            class_1
        ]
    }
)

fig_class = go.Figure()

fig_class.add_trace(
    go.Bar(
        x=class_df["Class"],
        y=class_df["Samples"],
        text=class_df["Samples"],
        textposition="auto",
        name="Samples"
    )
)

fig_class.update_layout(
    title="Global Dataset Class Distribution",
    xaxis_title="Class",
    yaxis_title="Number of Samples",
    height=400
)

st.plotly_chart(
    fig_class,
    width="stretch"
)

col1, col2 = st.columns(2)

with col1:

    st.success(
        f"🟢 Class 0 Samples: {class_0}"
    )

with col2:

    st.error(
        f"🔴 Class 1 Samples: {class_1}"
    )


# ============================================================
# AZURE GLOBAL MODEL PREDICTION
# ============================================================

st.header(
    "☁️ Azure Global Model Prediction"
)

prediction_test_samples = safe_int(
    find_nested_value(
        prediction_data,
        [
            "test_samples",
            "Test Samples",
            "total_test_samples"
        ],
        0
    )
)

prediction_correct = safe_int(
    find_nested_value(
        prediction_data,
        [
            "correct_predictions",
            "Correct Predictions",
            "correct"
        ],
        0
    )
)

prediction_incorrect = safe_int(
    find_nested_value(
        prediction_data,
        [
            "incorrect_predictions",
            "Incorrect Predictions",
            "incorrect"
        ],
        0
    )
)

prediction_accuracy = find_nested_value(
    prediction_data,
    [
        "accuracy",
        "model_accuracy",
        "Global Model Accuracy",
        "Model Accuracy"
    ],
    0
)

prediction_accuracy = safe_float(
    prediction_accuracy
)

if prediction_accuracy <= 1:
    prediction_accuracy *= 100


if prediction_test_samples > 0:

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        st.metric(
            "🧪 Test Samples",
            prediction_test_samples
        )

    with col2:

        st.metric(
            "✅ Correct Predictions",
            prediction_correct
        )

    with col3:

        st.metric(
            "❌ Incorrect Predictions",
            prediction_incorrect
        )

    with col4:

        st.metric(
            "🎯 Azure Model Accuracy",
            f"{prediction_accuracy:.2f}%"
        )


    st.success(
        "☁️ Azure global model prediction "
        "results loaded successfully."
    )


    # --------------------------------------------------------
    # PREDICTION PERFORMANCE CHART
    # --------------------------------------------------------

    prediction_df = pd.DataFrame(
        {
            "Result": [
                "Correct",
                "Incorrect"
            ],
            "Count": [
                prediction_correct,
                prediction_incorrect
            ]
        }
    )

    fig_prediction = go.Figure()

    fig_prediction.add_trace(
        go.Bar(
            x=prediction_df["Result"],
            y=prediction_df["Count"],
            text=prediction_df["Count"],
            textposition="auto",
            name="Predictions"
        )
    )

    fig_prediction.update_layout(
        title="Azure Global Model Prediction Performance",
        xaxis_title="Prediction Result",
        yaxis_title="Number of Samples",
        height=400
    )

    st.plotly_chart(
        fig_prediction,
        width="stretch"
    )


    # --------------------------------------------------------
    # COMPARISON
    # --------------------------------------------------------

    st.subheader(
        "🔍 Accuracy Comparison"
    )

    comparison_df = pd.DataFrame(
        {
            "Metric": [
                "Federated Final Accuracy",
                "Azure Global Model Accuracy"
            ],
            "Accuracy": [
                final_accuracy,
                prediction_accuracy
            ]
        }
    )

    fig_comparison = go.Figure()

    fig_comparison.add_trace(
        go.Bar(
            x=comparison_df["Metric"],
            y=comparison_df["Accuracy"],
            text=[
                f"{value:.2f}%"
                for value in comparison_df["Accuracy"]
            ],
            textposition="auto",
            name="Accuracy"
        )
    )

    fig_comparison.update_layout(
        title="Federated Accuracy vs Azure Model Test Accuracy",
        xaxis_title="Model Evaluation",
        yaxis_title="Accuracy (%)",
        yaxis=dict(
            range=[
                0,
                100
            ]
        ),
        height=420
    )

    st.plotly_chart(
        fig_comparison,
        width="stretch"
    )

    st.caption(
        "Federated accuracy is the round-wise server evaluation metric. "
        "Azure model accuracy is the independent evaluation obtained by "
        "downloading the stored global model and testing it on the "
        "combined 228-sample test dataset."
    )

else:

    st.info(
        "Azure prediction results are not available."
    )


# ============================================================
# GLOBAL MODEL
# ============================================================

st.header(
    "🧠 Global Federated Model"
)

local_model_path = "global_model.pth"
azure_model_path = "azure_global_model.pth"

model_path = None

if os.path.exists(
    azure_model_path
):

    model_path = azure_model_path

elif os.path.exists(
    local_model_path
):

    model_path = local_model_path


if model_path:

    model_size = os.path.getsize(
        model_path
    )

    st.success(
        "✅ Global federated model is loaded "
        "and ready for prediction."
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        st.write(
            "**Model File**"
        )

        st.code(
            model_path
        )

    with col2:

        st.write(
            "**Model Size**"
        )

        st.write(
            f"{model_size:,} bytes"
        )

    with col3:

        st.write(
            "**Parameters**"
        )

        st.write(
            "4,097"
        )

else:

    st.warning(
        "⚠️ Global federated model is not available locally."
    )


# ============================================================
# MODEL VERIFICATION
# ============================================================

st.subheader(
    "🔐 Model Integrity Verification"
)

global_hash = None
azure_hash = None

if os.path.exists(
    local_model_path
):

    try:

        import hashlib

        with open(
            local_model_path,
            "rb"
        ) as file:

            global_hash = hashlib.sha256(
                file.read()
            ).hexdigest()

    except Exception:

        global_hash = None


if os.path.exists(
    azure_model_path
):

    try:

        import hashlib

        with open(
            azure_model_path,
            "rb"
        ) as file:

            azure_hash = hashlib.sha256(
                file.read()
            ).hexdigest()

    except Exception:

        azure_hash = None


if global_hash and azure_hash:

    if global_hash == azure_hash:

        st.success(
            "✅ Integrity check passed: "
            "global_model.pth and azure_global_model.pth "
            "have identical SHA-256 hashes."
        )

        st.code(
            global_hash
        )

    else:

        st.error(
            "❌ Model integrity check failed. "
            "The local and Azure-downloaded models differ."
        )

else:

    st.info(
        "Model hash comparison unavailable."
    )


# ============================================================
# LIVE PREDICTION
# ============================================================

st.header(
    "🔮 Live Prediction"
)

st.write(
    "Enter 30 feature values to make a prediction "
    "using the trained global federated model."
)

feature_values = []

cols = st.columns(3)

for i in range(30):

    with cols[i % 3]:

        value = st.number_input(
            f"Feature {i + 1}",
            value=0.0,
            step=0.01,
            key=f"feature_{i + 1}"
        )

        feature_values.append(
            value
        )


if st.button(
    "🔮 Predict",
    width="stretch"
):

    try:

        import torch

        from model import FederatedModel

        if model_path is None:

            st.error(
                "Global model file not found."
            )

        else:

            model = FederatedModel()

            model.load_state_dict(
                torch.load(
                    model_path,
                    map_location="cpu"
                )
            )

            model.eval()

            x = torch.tensor(
                [feature_values],
                dtype=torch.float32
            )

            with torch.no_grad():

                output = model(
                    x
                )

                probability = torch.sigmoid(
                    output
                ).item()

            prediction = (
                1
                if probability >= 0.5
                else 0
            )

            st.subheader(
                "Prediction Result"
            )

            if prediction == 1:

                confidence = probability

                st.error(
                    f"🔴 Predicted Class: 1\n\n"
                    f"Confidence: {confidence:.2%}"
                )

            else:

                confidence = 1 - probability

                st.success(
                    f"🟢 Predicted Class: 0\n\n"
                    f"Confidence: {confidence:.2%}"
                )

    except Exception as e:

        st.error(
            f"Prediction error: {e}"
        )


# ============================================================
# ARCHITECTURE
# ============================================================

st.header(
    "🏗️ Federated Learning Architecture"
)

architecture = """
┌─────────────────────┐
│      Client 1       │
│                     │
│  Local Dataset      │
│  Local Training     │
└──────────┬──────────┘
           │
           │ Model Updates
           ▼
┌─────────────────────────────┐
│     Federated Server        │
│                             │
│          FedAvg             │
│     Model Aggregation       │
└──────────────┬──────────────┘
               │
               │ Global Model
               ▼
┌─────────────────────┐
│      Client 2       │
│                     │
│  Local Dataset      │
│  Local Training     │
└──────────┬──────────┘
           │
           │ Results / Model
           ▼
┌──────────────────────────────────────────┐
│          Azure Blob Storage              │
│                                          │
│ results/results.json                     │
│ analytics/analytics_results.json         │
│ models/global_model.pth                  │
│ predictions/azure_prediction_results.json│
└──────────────────────────────────────────┘
"""

st.code(
    architecture,
    language="text"
)


# ============================================================
# PRIVACY PRESERVATION
# ============================================================

st.header(
    "🔒 Privacy Preservation"
)

st.info(
    "Raw client data remains on the local devices. "
    "Only trained model parameters are communicated "
    "to the federated server. Federated results, "
    "analytics, models, and prediction results are "
    "stored in Azure Blob Storage."
)


# ============================================================
# SYSTEM STATUS
# ============================================================

st.header(
    "⚙️ System Status"
)

col1, col2, col3, col4, col5 = st.columns(5)

with col1:

    if rounds:

        st.success(
            "✅ Federated Results Available"
        )

    else:

        st.error(
            "❌ Federated Results Missing"
        )


with col2:

    if (
        training_samples > 0
        and test_samples > 0
        and features > 0
    ):

        st.success(
            "✅ Analytics Available"
        )

    else:

        st.error(
            "❌ Analytics Incomplete"
        )


with col3:

    if model_path:

        st.success(
            "🔐 Global Model Available"
        )

    else:

        st.error(
            "❌ Global Model Missing"
        )


with col4:

    if azure_connected:

        st.success(
            "☁️ Azure Connected"
        )

    else:

        st.error(
            "❌ Azure Offline"
        )


with col5:

    if prediction_test_samples > 0:

        st.success(
            "🔮 Azure Prediction Available"
        )

    else:

        st.warning(
            "⚠️ Azure Prediction Missing"
        )


# ============================================================
# FINAL RESULT
# ============================================================

st.header(
    "✅ Final Result"
)

st.markdown(
    f"""
The federated learning system completed **{len(rounds)} communication rounds**
and achieved a final federated accuracy of **{final_accuracy:.2f}%**.

The system performs local model training on multiple clients and uses
**Federated Averaging (FedAvg)** to create a global model without directly
transferring raw client data.

The federated analytics contain **{total_clients} clients**,
**{training_samples} training samples**, **{test_samples} test samples**,
and **{features} features**.
"""
)

if prediction_accuracy > 0:

    st.success(
        f"☁️ The global federated model downloaded from Azure achieved "
        f"**{prediction_accuracy:.2f}%** accuracy on the combined "
        f"federated test dataset (**{prediction_correct}/{prediction_test_samples} "
        f"correct predictions**)."
    )


# ============================================================
# PROJECT CONCLUSION
# ============================================================

st.subheader(
    "🎓 Project Conclusion"
)

st.write(
    "The implemented system demonstrates a privacy-preserving "
    "federated learning workflow in which individual clients "
    "train locally, model updates are aggregated using FedAvg, "
    "and the resulting global model and analytics are stored "
    "in Azure Blob Storage."
)

st.write(
    "The stored Azure global model was independently downloaded "
    "and evaluated on the combined test dataset, providing an "
    "additional verification stage for the cloud-deployed model."
)


# ============================================================
# FOOTER
# ============================================================

st.markdown(
    "---"
)

st.caption(
    "Privacy-Preserving Federated Learning | "
    "Python + PyTorch + Flower + Azure Blob Storage + Streamlit"
)
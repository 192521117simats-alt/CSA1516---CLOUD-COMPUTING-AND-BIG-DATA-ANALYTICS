import os
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv

load_dotenv()

print("=" * 60)
print("☁️ AZURE FEDERATED PROJECT STORAGE")
print("=" * 60)

connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
container_name = os.getenv("AZURE_CONTAINER_NAME", "federated-results")

if not connection_string:
    print("❌ AZURE_STORAGE_CONNECTION_STRING not found in .env")
    raise SystemExit(1)

try:
    blob_service = BlobServiceClient.from_connection_string(
        connection_string
    )

    container_client = blob_service.get_container_client(container_name)

    print(f"✅ Container: {container_name}")
    print("✅ Azure connection successful!")

except Exception as e:
    print("❌ Azure connection failed")
    print(e)
    raise SystemExit(1)


files_to_upload = [
    ("results.json", "results/results.json"),
    ("analytics_results.json", "analytics/analytics_results.json"),
    ("global_model.pth", "models/global_model.pth"),
]

print("\n" + "=" * 60)
print("📤 UPLOADING PROJECT FILES")
print("=" * 60)

uploaded = 0

for local_file, blob_name in files_to_upload:

    if not os.path.exists(local_file):
        print(f"⚠️ Not found: {local_file}")
        continue

    try:
        with open(local_file, "rb") as data:

            blob_client = container_client.get_blob_client(blob_name)

            blob_client.upload_blob(
                data,
                overwrite=True
            )

        size = os.path.getsize(local_file)

        print(f"✅ Uploaded: {local_file}")
        print(f"   Azure Blob: {blob_name}")
        print(f"   Size: {size:,} bytes")

        uploaded += 1

    except Exception as e:
        print(f"❌ Upload failed: {local_file}")
        print(f"   Error: {e}")


print("\n" + "=" * 60)
print("📊 UPLOAD SUMMARY")
print("=" * 60)

print(f"✅ Files uploaded: {uploaded}/{len(files_to_upload)}")

print("\n☁️ Azure Blob Storage structure:")
print("federated-results/")
print("├── results/")
print("│   └── results.json")
print("├── analytics/")
print("│   └── analytics_results.json")
print("└── models/")
print("    └── global_model.pth")

print("\n" + "=" * 60)

if uploaded == len(files_to_upload):
    print("🎉 ALL FEDERATED PROJECT FILES UPLOADED")
else:
    print("⚠️ Some files were not uploaded.")

print("=" * 60)
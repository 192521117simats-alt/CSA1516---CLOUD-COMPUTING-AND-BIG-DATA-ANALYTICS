import torch
import numpy as np

from model import FederatedModel
from data_utils import create_client_data


print("=" * 60)
print("🔮 GLOBAL FEDERATED MODEL PREDICTION")
print("=" * 60)


# ---------------------------------------------------------
# 1. Load the trained global model
# ---------------------------------------------------------

model = FederatedModel()

model.load_state_dict(
    torch.load(
        "global_model.pth",
        map_location=torch.device("cpu")
    )
)

model.eval()

print("✅ Global model loaded successfully")


# ---------------------------------------------------------
# 2. Load test data
# ---------------------------------------------------------

X1, y1, X_test1, y_test1 = create_client_data(1)

X2, y2, X_test2, y_test2 = create_client_data(2)


# Combine test data from both clients
X_test = np.vstack((X_test1, X_test2))
y_test = np.concatenate((y_test1, y_test2))


print(f"🧪 Test samples: {len(X_test)}")
print(f"🔢 Features: {X_test.shape[1]}")


# ---------------------------------------------------------
# 3. Convert data to PyTorch tensors
# ---------------------------------------------------------

X_tensor = torch.tensor(
    X_test,
    dtype=torch.float32
)

y_tensor = torch.tensor(
    y_test,
    dtype=torch.float32
).reshape(-1, 1)


# ---------------------------------------------------------
# 4. Make predictions
# ---------------------------------------------------------

with torch.no_grad():

    outputs = model(X_tensor)

    probabilities = torch.sigmoid(outputs)

    predictions = (
        probabilities >= 0.5
    ).float()


# ---------------------------------------------------------
# 5. Calculate accuracy
# ---------------------------------------------------------

correct = (
    predictions == y_tensor
).sum().item()

total = len(y_test)

accuracy = correct / total


# ---------------------------------------------------------
# 6. Display results
# ---------------------------------------------------------

print()
print("=" * 60)
print("📊 GLOBAL MODEL RESULTS")
print("=" * 60)

print(f"🧪 Test Samples      : {total}")
print(f"✅ Correct Predictions: {correct}")
print(f"❌ Incorrect Predictions: {total - correct}")

print(
    f"🎯 Global Model Accuracy: {accuracy * 100:.2f}%"
)


# ---------------------------------------------------------
# 7. Show sample predictions
# ---------------------------------------------------------

print()
print("=" * 60)
print("🔍 SAMPLE PREDICTIONS")
print("=" * 60)

for i in range(min(10, total)):

    actual = int(y_test[i])
    predicted = int(predictions[i].item())
    confidence = probabilities[i].item()

    status = "✅" if actual == predicted else "❌"

    print(
        f"{status} Sample {i + 1:02d} | "
        f"Actual: {actual} | "
        f"Predicted: {predicted} | "
        f"Confidence: {confidence:.2f}"
    )


print()
print("=" * 60)
print("✅ GLOBAL MODEL TEST COMPLETED")
print("=" * 60)
import os
import json
import flwr as fl
import torch

from model import FederatedModel


# ============================================================
# FEDERATED LEARNING SERVER
# ============================================================

print("=" * 60)
print("FEDERATED LEARNING SERVER")
print("=" * 60)


# ============================================================
# CONFIGURATION
# ============================================================

SERVER_HOST = os.getenv("FL_SERVER_HOST", "0.0.0.0")
SERVER_PORT = int(os.getenv("FL_SERVER_PORT", "8080"))

NUM_ROUNDS = 3

round_numbers = []
accuracies = []


# ============================================================
# EVALUATION METRIC AGGREGATION
# ============================================================

def evaluate_metrics_aggregation(metrics):

    if not metrics:
        return {}

    total_examples = sum(
        num_examples
        for num_examples, _ in metrics
    )

    if total_examples == 0:
        return {}

    accuracy = sum(
        num_examples * values.get("accuracy", 0.0)
        for num_examples, values in metrics
    ) / total_examples

    print(
        f"Round accuracy: {accuracy * 100:.2f}%"
    )

    return {
        "accuracy": accuracy
    }


# ============================================================
# SAVE GLOBAL MODEL
# ============================================================

class SaveModelFedAvg(fl.server.strategy.FedAvg):

    def aggregate_fit(
        self,
        server_round,
        results,
        failures
    ):

        if not results:
            print("No client results received.")
            return None, {}

        print(
            f"\nAggregating Round {server_round}"
        )

        aggregated_parameters, aggregated_metrics = (
            super().aggregate_fit(
                server_round,
                results,
                failures
            )
        )

        if aggregated_parameters is None:
            print("Aggregation failed.")
            return None, aggregated_metrics

        try:

            parameters = (
                fl.common.parameters_to_ndarrays(
                    aggregated_parameters
                )
            )

            model = FederatedModel()

            model_parameters = list(
                model.state_dict().keys()
            )

            if len(parameters) != len(model_parameters):

                print(
                    "Model parameter count mismatch."
                )

                return (
                    aggregated_parameters,
                    aggregated_metrics
                )

            state_dict = {}

            for key, value in zip(
                model_parameters,
                parameters
            ):

                state_dict[key] = torch.tensor(
                    value
                )

            model.load_state_dict(
                state_dict
            )

            torch.save(
                model.state_dict(),
                "global_model.pth"
            )

            print(
                "Global model saved: "
                "global_model.pth"
            )

        except Exception as e:

            print(
                f"Error saving global model: {e}"
            )

        return (
            aggregated_parameters,
            aggregated_metrics
        )


# ============================================================
# FEDAVG STRATEGY
# ============================================================

strategy = SaveModelFedAvg(

    fraction_fit=1.0,

    fraction_evaluate=1.0,

    min_fit_clients=2,

    min_evaluate_clients=2,

    min_available_clients=2,

    evaluate_metrics_aggregation_fn=(
        evaluate_metrics_aggregation
    )

)


# ============================================================
# SERVER INFORMATION
# ============================================================

print(
    f"Server Host       : {SERVER_HOST}"
)

print(
    f"Server Port       : {SERVER_PORT}"
)

print(
    f"Federated Rounds  : {NUM_ROUNDS}"
)

print(
    "Required Clients  : 2"
)

print("=" * 60)


# ============================================================
# START SERVER
# ============================================================

history = fl.server.start_server(

    server_address=(
        f"{SERVER_HOST}:{SERVER_PORT}"
    ),

    config=fl.server.ServerConfig(
        num_rounds=NUM_ROUNDS
    ),

    strategy=strategy
)


# ============================================================
# EXTRACT FINAL ACCURACY FROM HISTORY
# ============================================================

if hasattr(history, "metrics_distributed"):

    distributed_metrics = (
        history.metrics_distributed
    )

    if "accuracy" in distributed_metrics:

        for round_number, accuracy in (
            distributed_metrics["accuracy"]
        ):

            round_numbers.append(
                round_number
            )

            accuracies.append(
                accuracy
            )


# ============================================================
# SAVE RESULTS
# ============================================================

results = {

    "rounds": round_numbers,

    "accuracy": accuracies

}


with open(
    "results.json",
    "w"
) as f:

    json.dump(
        results,
        f,
        indent=4
    )


# ============================================================
# FINAL STATUS
# ============================================================

print("\n" + "=" * 60)

print(
    "FEDERATED TRAINING COMPLETED"
)

print("=" * 60)

print(
    f"Communication Rounds : "
    f"{len(round_numbers)}"
)

if accuracies:

    print(
        f"Final Accuracy       : "
        f"{accuracies[-1] * 100:.2f}%"
    )

else:

    print(
        "Final Accuracy       : Not available"
    )

print(
    "Global Model         : "
    "global_model.pth"
)

print(
    "Results File         : "
    "results.json"
)

print("=" * 60)